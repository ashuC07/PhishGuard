# PhishGuard AI

An advanced Applied Linear Algebra / CSE mini-project: a local web application that classifies pasted email text into **phishing**, **spam**, or **legitimate** using TF-IDF features and multiclass Logistic Regression.

## Features

- Dark cybersecurity dashboard with scan totals and classification distribution
- Email scanner with three-class prediction and class probability display
- Linear Algebra Math Lab: feature-vector dimensions, non-zero TF-IDF features, learned weights, feature contributions, and class decision scores
- SQLite scan history (stored locally in `scans.db`)
- JSON API endpoints for scanning, history, model information, and health checks
- Bundled labelled classroom dataset in `data.csv`

## Requirements

- Python 3.10 or newer
- Internet is not required to run the backend after dependencies are installed. Google Fonts and Chart.js are optional external frontend enhancements; the scanner itself works without them.

## Run on Windows (VS Code)

1. Extract `PhishGuard_AI.zip`.
2. Open the extracted `PhishGuard_AI` folder in VS Code.
3. Open Terminal in that folder and create a virtual environment:

   ```powershell
   py -m venv .venv
   .venv\Scripts\activate
   ```

4. Install dependencies:

   ```powershell
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

5. Start the app:

   ```powershell
   python app.py
   ```

6. Open **http://127.0.0.1:5000** in your browser.
7. Stop the server with `Ctrl+C` in the terminal.

## Run on macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python app.py
```

Then visit `http://127.0.0.1:5000`.

## API endpoints

- `GET /api/health` — app/model health
- `GET /api/model-info` — model and training dataset information
- `GET /api/history` — latest 50 scan records
- `POST /api/scan` — classify email text. JSON body: `{"email":"paste email content here"}`

Example PowerShell test:

```powershell
Invoke-RestMethod -Uri http://127.0.0.1:5000/api/scan -Method Post -ContentType 'application/json' -Body '{"email":"Your account is locked. Verify your password immediately using this link."}'
```

## Linear Algebra used

1. TF-IDF converts email text into a sparse feature vector `x`.
2. The trained Logistic Regression model stores a coefficient matrix `W` and bias vector `b`.
3. Class decision scores are calculated as `z = x W^T + b`.
4. The predicted class is the class with the largest decision score. Softmax-normalised class probabilities are returned by the model.
5. The Math Lab displays active feature values, learned weights, and per-feature contributions `x_i * w_i` for the predicted class.

## Important academic and security note

The included CSV is a small, hand-curated teaching dataset so the project runs immediately. It is **not** a representative benchmark and does not establish real-world accuracy. Confidence is a model probability, not a guarantee. Before making performance claims, obtain a larger, legally usable and independently labelled dataset, remove duplicates, split it into training/validation/test sets, and report per-class precision, recall, F1-score and a confusion matrix. Never paste real passwords, personal data, or confidential emails into this classroom prototype. It does not inspect live inboxes, attachments, sender authentication, or the actual reputation of URLs.

## Troubleshooting

- `ModuleNotFoundError`: activate the virtual environment and run `pip install -r requirements.txt` again.
- Port 5000 busy: close the other app using port 5000, or change `port=5000` at the bottom of `app.py`.
- Dataset error: make sure `data.csv` remains beside `app.py` and retains the columns `text,label`.
- Blank chart when offline: Chart.js is loaded from a CDN; scanning and classification still work. Connect to the internet for the chart library.
