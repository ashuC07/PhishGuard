"""PhishGuard AI - educational three-class email screening application."""
from pathlib import Path
import sqlite3
from datetime import datetime

import numpy as np
import pandas as pd
from flask import Flask, jsonify, render_template, request
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "data.csv"
DB_PATH = BASE_DIR / "scans.db"
ALLOWED_LABELS = {"phishing", "spam", "legitimate"}
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024


def load_training_data():
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Training dataset not found: {DATA_PATH}")
    df = pd.read_csv(DATA_PATH).dropna(subset=["text", "label"])
    df["text"] = df["text"].astype(str).str.strip()
    df["label"] = df["label"].astype(str).str.strip().str.lower()
    df = df[(df["text"].str.len() > 0) & df["label"].isin(ALLOWED_LABELS)]
    if len(df) < 15 or set(df["label"].unique()) != ALLOWED_LABELS:
        raise RuntimeError("data.csv must contain at least 15 labelled rows across phishing, spam and legitimate.")
    return df


def train_model():
    df = load_training_data()
    model = Pipeline([
        ("tfidf", TfidfVectorizer(
            lowercase=True, stop_words="english", ngram_range=(1, 2),
            max_features=8000, sublinear_tf=True
        )),
        ("classifier", LogisticRegression(
            max_iter=2000, class_weight="balanced", random_state=42
        )),
    ])
    model.fit(df["text"], df["label"])
    return model, len(df), {str(k): int(v) for k, v in df["label"].value_counts().items()}


MODEL, TRAINING_ROWS, CLASS_COUNTS = train_model()


def db_connection():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db_connection() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            category TEXT NOT NULL,
            confidence REAL NOT NULL,
            email_preview TEXT NOT NULL
        )""")


init_db()


def get_math_explanation(text, predicted_label):
    vectorizer = MODEL.named_steps["tfidf"]
    classifier = MODEL.named_steps["classifier"]
    x = vectorizer.transform([text])
    class_index = list(classifier.classes_).index(predicted_label)
    weights = classifier.coef_[class_index]
    dense_x = x.toarray()[0]
    contributions = dense_x * weights
    feature_names = vectorizer.get_feature_names_out()
    active = np.flatnonzero(dense_x)
    top = sorted(active, key=lambda i: abs(contributions[i]), reverse=True)[:8]
    terms = [{
        "term": str(feature_names[i]),
        "tfidf": round(float(dense_x[i]), 4),
        "weight": round(float(weights[i]), 4),
        "contribution": round(float(contributions[i]), 4),
    } for i in top]
    scores = classifier.decision_function(x)[0]
    score_map = {str(c): round(float(s), 4) for c, s in zip(classifier.classes_, scores)}
    return {
        "feature_count": int(x.nnz),
        "vector_shape": [1, int(x.shape[1])],
        "classes": [str(c) for c in classifier.classes_],
        "decision_scores": score_map,
        "top_features": terms,
        "formula": "z_k = w_k^T x + b_k; prediction = argmax_k(z_k)",
        "note": "TF-IDF converts the email into a sparse numerical feature vector. Logistic Regression applies learned weights and bias to calculate class scores.",
    }


def classify(text):
    probabilities = MODEL.predict_proba([text])[0]
    predicted = str(MODEL.predict([text])[0])
    confidence = float(np.max(probabilities)) * 100
    probability_map = {
        str(label): round(float(probability) * 100, 2)
        for label, probability in zip(MODEL.named_steps["classifier"].classes_, probabilities)
    }
    return predicted, confidence, probability_map, get_math_explanation(text, predicted)


@app.get("/")
def index():
    with db_connection() as con:
        total = con.execute("SELECT COUNT(*) FROM scans").fetchone()[0]
        rows = con.execute("SELECT category, COUNT(*) AS n FROM scans GROUP BY category").fetchall()
        recent = con.execute(
            "SELECT id, created_at, category, confidence, email_preview FROM scans ORDER BY id DESC LIMIT 6"
        ).fetchall()
    counts = {label: 0 for label in ALLOWED_LABELS}
    counts.update({row["category"]: row["n"] for row in rows})
    return render_template(
        "index.html", total=total, counts=counts, recent=recent,
        training_rows=TRAINING_ROWS
    )


@app.post("/api/scan")
def scan():
    payload = request.get_json(silent=True) or request.form
    text = str(payload.get("email", "")).strip()
    if len(text) < 12:
        return jsonify({"error": "Please enter at least 12 characters of email content."}), 400
    if len(text) > 20000:
        return jsonify({"error": "Email is too long. Please keep it under 20,000 characters."}), 400
    label, confidence, probabilities, math_info = classify(text)
    created = datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")
    preview = " ".join(text.split())[:140]
    with db_connection() as con:
        cur = con.execute(
            "INSERT INTO scans(created_at, category, confidence, email_preview) VALUES (?, ?, ?, ?)",
            (created, label, confidence, preview),
        )
        scan_id = cur.lastrowid
    return jsonify({
        "id": scan_id, "category": label, "confidence": round(confidence, 2),
        "probabilities": probabilities, "math": math_info, "created_at": created,
        "disclaimer": "Educational screening only. This model can make mistakes; a prediction is not proof that an email is safe or malicious.",
    })


@app.get("/api/history")
def history():
    with db_connection() as con:
        rows = con.execute(
            "SELECT id, created_at, category, confidence, email_preview FROM scans ORDER BY id DESC LIMIT 50"
        ).fetchall()
    return jsonify([{
        "id": r["id"], "created_at": r["created_at"], "category": r["category"],
        "confidence": round(r["confidence"], 2), "preview": r["email_preview"],
    } for r in rows])


@app.get("/api/model-info")
def model_info():
    clf = MODEL.named_steps["classifier"]
    return jsonify({
        "algorithm": "TF-IDF + Multiclass Logistic Regression",
        "training_rows": TRAINING_ROWS, "class_counts": CLASS_COUNTS,
        "classes": [str(c) for c in clf.classes_],
        "features": len(MODEL.named_steps["tfidf"].get_feature_names_out()),
        "linear_algebra": "Sparse feature matrix X, coefficient matrix W and bias vector b; class scores are XW^T + b.",
        "warning": "The bundled dataset is a small classroom demonstration dataset. Do not use this prototype as a real security gateway.",
    })


@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "model_loaded": True, "training_rows": TRAINING_ROWS})


@app.errorhandler(413)
def too_large(_error):
    return jsonify({"error": "Request too large. Please keep email content under 20,000 characters."}), 413


if __name__ == "__main__":
    # Debug is disabled by default. This server is intended for local demonstration.
    app.run(host="127.0.0.1", port=5000, debug=False)
