@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Creating Python virtual environment...
  py -m venv .venv
)
call .venv\Scripts\activate.bat
echo Installing or checking required packages...
python -m pip install --upgrade pip
pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Dependency installation failed. Check your internet connection and Python installation.
  pause
  exit /b 1
)
echo.
echo Starting PhishGuard AI at http://127.0.0.1:5000
python app.py
pause
